after make install don't forget to do sudo -l ldconfig!
